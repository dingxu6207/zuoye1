# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 15:57:19 2019

@author: dingxu
"""

from astropy.io import fits
import matplotlib.pyplot as plt
import numpy as np
import math


hdu = fits.open('Mimas.fits')
imagedata = hdu[0].data

###D0截止频率，c锐化系数，Hh高频增益，Hl低频增益###
def Homomorphicfiltering(image,D0,c ,Hh,Hl): 
    ###FFT变换###
    fimagedata = np.float64(image)
    logimag = np.log(fimagedata+1)
    Fimag = np.fft.fft2(logimag)
    cenFimg = np.fft.fftshift(Fimag)

    ###滤波器###
    hang,lie = imagedata.shape
    centerx = math.floor(hang/2)
    centery = math.floor(lie/2)

    D = np.zeros((hang,lie),dtype = np.float64)
    H = np.zeros((hang,lie),dtype = np.float64)
    for u in range(hang):
        for v in range(lie):
            D[u,v] = math.sqrt((u-centerx)**2+(v-centery)**2)
            H[u,v]=(Hh-Hl)*(1-math.exp(-c*(D[u,v]**2/D0**2)))+Hl

    mulimage = cenFimg*H

    ###FFT反变换###
    icenimg = np.fft.ifftshift(mulimage)
    imageifft = np.fft.ifft2(icenimg)
    dstimage = np.real(imageifft)
    eimage = np.exp(dstimage)-1

    maxdata = np.max(eimage)
    mindata = np.min(eimage)
    redst = 255*(eimage - mindata)/(maxdata-mindata)
    redst = np.uint8(redst)

    return redst


redst = Homomorphicfiltering(imagedata ,D0 = 1024,c = 0.4 ,Hh = 2.2 ,Hl = 0.2) 

fig = plt.figure()

ax = fig.add_subplot(121)
ax.imshow(imagedata,cmap='gray')
plt.title('Original Image')

ax = fig.add_subplot(122)
ax.imshow(redst,cmap='gray')
plt.title('Filtered  Image')



